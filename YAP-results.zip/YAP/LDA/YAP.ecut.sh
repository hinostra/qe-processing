#!/bin/sh
#SBATCH -J yap-ecut-lda
#SBATCH --nodes=1
#SBATCH --mem=30000M
#SBATCH --tasks-per-node=8
#SBATCH --time=4:00:00
#SBATCH --account=def-barakat
#SBATCH --mail-type=all
#SBATCH         --mail-user=hinostro@ualberta.ca

module load StdEnv/2020  intel/2020.1.217  openmpi/4.0.3
module load quantumespresso/7.2

prefix='YAP'

for CUTOFF in 140 150 160 170 180
do
CUTRHO=$((CUTOFF*8))
cat > $prefix.ecut_$CUTOFF.in << EOF
&CONTROL
  calculation   = 'scf'
  outdir        = './out'
  prefix        = 'yap'
  pseudo_dir    = '../../pseudoLDA'
  tprnfor       = .true.
  tstress       = .true.
  etot_conv_thr =  8.0d-04
  forc_conv_thr =  1.0d-04
  verbosity     = 'high'
/
&SYSTEM
  ibrav       = 0
  nat         = 20
  ntyp        = 3
  ecutwfc     = $CUTOFF
  ecutrho     = $CUTRHO
  occupations = 'smearing'
  smearing    = 'cold'
  degauss     = 0.015
  nosym       = .false.
/
&ELECTRONS
  conv_thr         = 4.0d-09
  electron_maxstep = 200
  mixing_beta      = 4.00d-01
/
ATOMIC_SPECIES
Al     26.981538   Al.upf
O      15.9994     O.upf
Y      88.90585    Y.upf
ATOMIC_POSITIONS crystal
O            0.7054000000       0.2933000000       0.0431000000 
O            0.2054000000       0.2067000000       0.9569000000 
O            0.7946000000       0.7933000000       0.4569000000 
O            0.2946000000       0.7067000000       0.5431000000 
O            0.2946000000       0.7067000000       0.9569000000 
O            0.7946000000       0.7933000000       0.0431000000 
O            0.2054000000       0.2067000000       0.5431000000 
O            0.7054000000       0.2933000000       0.4569000000 
Y            0.9884200000       0.0519500000       0.2500000000 
Y            0.4884200000       0.4480500000       0.7500000000 
Y            0.5115800000       0.5519500000       0.2500000000 
Y            0.0115800000       0.9480500000       0.7500000000 
Al           0.0000000000       0.5000000000       0.5000000000 
Al           0.5000000000       0.0000000000       0.5000000000 
Al           0.5000000000       0.0000000000       0.0000000000 
Al           0.0000000000       0.5000000000       0.0000000000 
O            0.0832000000       0.4805000000       0.2500000000 
O            0.5832000000       0.0195000000       0.7500000000 
O            0.4168000000       0.9805000000       0.2500000000 
O            0.9168000000       0.5195000000       0.7500000000 
K_POINTS automatic
5 4 3 0 0 0
CELL_PARAMETERS angstrom
      5.1609800000       0.0000000000       0.0000000000
      0.0000000000       5.3010200000       0.0000000000
      0.0000000000       0.0000000000       7.3418100000
EOF

srun pw.x -in $prefix.ecut_$CUTOFF.in > $prefix.ecut_$CUTOFF.out
done
