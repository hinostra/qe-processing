#!/bin/sh
#SBATCH -J yap-scf-pbesol
#SBATCH --nodes=1
#SBATCH --mem=128000M
#SBATCH --tasks-per-node=32
#SBATCH --time=10:00
#SBATCH --account=def-barakat
#SBATCH --mail-type=all
#SBATCH         --mail-user=hinostro@ualberta.ca

module load StdEnv/2020  intel/2020.1.217  openmpi/4.0.3
module load quantumespresso/7.2

prefix='YAP'

cat > $prefix.scf.in << EOF
&CONTROL
  calculation   = 'scf'
  outdir        = './out'
  prefix        = 'yap'
  pseudo_dir    = '../../pseudoPBEsol'
  tprnfor       = .true.
  tstress       = .true.
  etot_conv_thr =  1.0d-05
  forc_conv_thr =  1.0d-04
  verbosity     = 'high'
/
&SYSTEM
  ibrav       = 0
  nat         = 20
  ntyp        = 3
  ecutwfc     = 140
  ecutrho     = 1120
  nbnd        = 80
  occupations = 'fixed'
/
&ELECTRONS
  conv_thr         = 4.0d-09
  electron_maxstep = 200
  mixing_beta      = 4.00d-01
/
ATOMIC_SPECIES
Al     26.981538   Al.upf
O      15.9994     O.upf
Y      88.90585    Y.upf
ATOMIC_POSITIONS (crystal)
O             0.7048199132        0.2946008518        0.0459536238
O             0.2048199132        0.2053991482        0.9540463762
O             0.7951800868        0.7946008518        0.4540463762
O             0.2951800868        0.7053991482        0.5459536238
O             0.2951800868        0.7053991482        0.9540463762
O             0.7951800868        0.7946008518        0.0459536238
O             0.2048199132        0.2053991482        0.5459536238
O             0.7048199132        0.2946008518        0.4540463762
Y             0.9866772589        0.0554749183        0.2500000000
Y             0.4866772589        0.4445250817        0.7500000000
Y             0.5133227411        0.5554749183        0.2500000000
Y             0.0133227411        0.9445250817        0.7500000000
Al            0.0000000000        0.5000000000        0.5000000000
Al            0.5000000000        0.0000000000        0.5000000000
Al            0.5000000000	  0.0000000000        0.0000000000
Al            0.0000000000        0.5000000000        0.0000000000
O             0.0872135265        0.4766647417        0.2500000000
O             0.5872135265        0.0233352583        0.7500000000
O             0.4127864735        0.9766647417        0.2500000000
O             0.9127864735        0.5233352583        0.7500000000
K_POINTS automatic
5 5 4 0 0 0
CELL_PARAMETERS angstrom
   5.165214925   0.000000000   0.000000000
   0.000000000   5.331524465   0.000000000
   0.000000000   0.000000000   7.368936583
EOF

srun pw.x -in $prefix.scf.in > $prefix.scf.out
