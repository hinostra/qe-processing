#!/bin/sh
#SBATCH -J yap-dos-pbe
#SBATCH --nodes=1
#SBATCH --mem=128000M
#SBATCH --tasks-per-node=32
#SBATCH --time=1-00:00:00
#SBATCH --account=def-barakat
#SBATCH --mail-type=all
#SBATCH         --mail-user=hinostro@ualberta.ca

module load StdEnv/2020  intel/2020.1.217  openmpi/4.0.3
module load quantumespresso/7.2

prefix='YAP'

cat > $prefix.nscf.in << EOF
&CONTROL
  calculation   = 'nscf'
  outdir        = './out'
  prefix        = 'yap'
  pseudo_dir    = '../../pseudoPBE'
  verbosity     = 'high'
/
&SYSTEM
  ibrav       = 0
  nat         = 20
  ntyp        = 3
  ecutwfc     = 140
  ecutrho     = 1120
  nbnd        = 80
  occupations = 'tetrahedra'
/
&ELECTRONS
  conv_thr         = 4.0d-09
  electron_maxstep = 200
  mixing_beta      = 4.00d-01
/
ATOMIC_SPECIES
Al     26.981538   Al.upf
O      15.9994     O.upf
Y      88.90585    Y.upf
ATOMIC_POSITIONS crystal
O             0.7047496369        0.2948970624        0.0464440072
O             0.2047496369        0.2051029376        0.9535559928
O             0.7952503631        0.7948970624        0.4535559928
O             0.2952503631        0.7051029376        0.5464440072
O             0.2952503631        0.7051029376        0.9535559928
O             0.7952503631        0.7948970624        0.0464440072
O             0.2047496369        0.2051029376        0.5464440072
O             0.7047496369        0.2948970624        0.4535559928
Y             0.9866945917        0.0555432111        0.2500000000
Y             0.4866945917        0.4444567889        0.7500000000
Y             0.5133054083        0.5555432111        0.2500000000
Y             0.0133054083        0.9444567889        0.7500000000
Al           -0.0000000000        0.5000000000        0.5000000000
Al            0.5000000000       -0.0000000000        0.5000000000
Al            0.5000000000       -0.0000000000        0.0000000000
Al           -0.0000000000        0.5000000000        0.0000000000
O             0.0882368718        0.4754887309        0.2500000000
O             0.5882368718        0.0245112691        0.7500000000
O             0.4117631282        0.9754887309        0.2500000000
O             0.9117631282        0.5245112691        0.7500000000
K_POINTS automatic
8 8 7 0 0 0
CELL_PARAMETERS angstrom
   5.212138168   0.000000000   0.000000000
   0.000000000   5.383077833   0.000000000
   0.000000000   0.000000000   7.440562131
EOF

srun pw.x -in $prefix.nscf.in > $prefix.nscf.out

cat > $prefix.dos.in << EOF
&DOS
  prefix = 'yap'
  outdir = './out'
  fildos = 'yap_dos.dat'
  emin   = -5.0
  emax   = 25.0
/
EOF

srun dos.x -in $prefix.dos.in > $prefix.dos.out

cat > $prefix.pdos.in << EOF
&PROJWFC
  prefix= 'yap',
  outdir= './out',
  filpdos= 'yap_pdos.dat'
/
EOF

srun projwfc.x -in $prefix.pdos.in > $prefix.pdos.out
